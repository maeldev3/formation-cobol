       IDENTIFICATION DIVISION.
       PROGRAM-ID. BANK-TRANSFER-MANAGER.
       
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       -- Navigation & Saisie utilisateur
       01 WS-CHOICE         PIC 9.
       01 WS-SUB-CHOICE     PIC 9.
       
       -- Variables métiers (Virements et comptes)
       01 WS-ID-EMETTEUR    PIC 9(4).
       01 WS-ID-DEST        PIC 9(4).
       01 WS-MONTANT-STR    PIC X(10).
       01 WS-MOTIF          PIC X(50).
       01 WS-IBAN-DEST      PIC X(34).
       01 WS-ID-BENEF       PIC 9(4).
       01 WS-CLIENT-ID      PIC 9(4).
       
       -- Variables système & Contexte SQLite
       01 WS-COMMAND        PIC X(1200).
       01 WS-DBL-QUOTE      PIC X VALUE '"'.
       01 WS-SGL-QUOTE      PIC X VALUE "'".
       
       PROCEDURE DIVISION.
       MAIN-LOGIC.
           PERFORM INITIALIZE-DATABASE
           PERFORM UNTIL WS-CHOICE = 5
               DISPLAY " "
               DISPLAY "============================================="
               DISPLAY "       BANK TRANSFER MANAGEMENT SYSTEM       "
               DISPLAY "============================================="
               DISPLAY "1. Exécuter un Virement Interne"
               DISPLAY "2. Exécuter un Virement Externe"
               DISPLAY "3. Consultation des Soldes & Comptes"
               DISPLAY "4. Rapports & Historiques des transactions"
               DISPLAY "5. Quitter l'application"
               DISPLAY "---------------------------------------------"
               DISPLAY "Saisissez votre choix (1-5) : " NO ADVANCING
               ACCEPT WS-CHOICE
               
               EVALUATE WS-CHOICE
                   WHEN 1 PERFORM VIREMENT-INTERNE
                   WHEN 2 PERFORM VIREMENT-EXTERNE
                   WHEN 3 PERFORM COMPTE-CONSULTATION
                   WHEN 4 PERFORM HISTORIQUE-MENU
                   WHEN 5 DISPLAY "Déconnexion sécurisée validée. Au revoir."
                   WHEN OTHER DISPLAY "⚠️ Choix invalide, veuillez réessayer."
               END-EVALUATE
           END-PERFORM
           STOP RUN.

       INITIALIZE-DATABASE.
           STRING 
               "sqlite3 data/banque.db < db/schema.sql"
               DELIMITED BY SIZE INTO WS-COMMAND
           END-STRING
           CALL "SYSTEM" USING WS-COMMAND.

       COMPTE-CONSULTATION.
           DISPLAY " "
           DISPLAY "--- LISTE DES COMPTES ET CLIENTS ASSOCIES ---"
           STRING
               "sqlite3 -header -column data/banque.db "
               WS-DBL-QUOTE
               "SELECT cl.id_client, cl.nom, cl.prenom, co.id_compte, co.numero_compte, co.solde || ' ' || co.devise AS solde_actuel "
               "FROM clients cl JOIN comptes co ON cl.id_client = co.id_client;"
               WS-DBL-QUOTE
               DELIMITED BY SIZE INTO WS-COMMAND
           END-STRING
           CALL "SYSTEM" USING WS-COMMAND.

       VIREMENT-INTERNE.
           PERFORM COMPTE-CONSULTATION
           DISPLAY " "
           DISPLAY "--- NOUVEAU VIREMENT INTERNE ---"
           DISPLAY "ID du compte Émetteur : " NO ADVANCING
           ACCEPT WS-ID-EMETTEUR
           DISPLAY "ID du compte Destinataire : " NO ADVANCING
           ACCEPT WS-ID-DEST
           DISPLAY "Montant du transfert (ex: 150.00) : " NO ADVANCING
           ACCEPT WS-MONTANT-STR
           DISPLAY "Motif du virement : " NO ADVANCING
           ACCEPT WS-MOTIF
           
           PERFORM ESCAPE-MOTIF-QUOTES
           
           -- Transaction SQL atomique avec contrôle de solde dynamique
           STRING
               "sqlite3 data/banque.db "
               WS-DBL-QUOTE
               "BEGIN TRANSACTION; "
               "UPDATE comptes SET solde = solde - " FUNCTION TRIM(WS-MONTANT-STR)
               " WHERE id_compte = " WS-ID-EMETTEUR " AND solde >= " FUNCTION TRIM(WS-MONTANT-STR) "; "
               "UPDATE comptes SET solde = solde + " FUNCTION TRIM(WS-MONTANT-STR)
               " WHERE id_compte = " WS-ID-DEST " AND (SELECT changes() > 0); "
               "INSERT INTO virements (id_compte_emetteur, type_virement, id_compte_destinataire, montant, motif, statut) "
               "SELECT " WS-ID-EMETTEUR ", 'INTERNE', " WS-ID-DEST ", " FUNCTION TRIM(WS-MONTANT-STR) ", "
               WS-SGL-QUOTE FUNCTION TRIM(WS-MOTIF) WS-SGL-QUOTE ", "
               "CASE WHEN changes() > 0 THEN 'EXECUTE' ELSE 'ECHEC' END; "
               "COMMIT;"
               WS-DBL-QUOTE
               DELIMITED BY SIZE INTO WS-COMMAND
           END-STRING
           
           CALL "SYSTEM" USING WS-COMMAND
           DISPLAY "✔️ Ordre de virement exécuté (Consulter l'historique pour valider le statut).".

       VIREMENT-EXTERNE.
           PERFORM COMPTE-CONSULTATION
           DISPLAY " "
           DISPLAY "--- NOUVEAU VIREMENT EXTERNE ---"
           DISPLAY "ID du compte Émetteur : " NO ADVANCING
           ACCEPT WS-ID-EMETTEUR
           
           DISPLAY " "
           DISPLAY "--- LISTE DES BENEFICIAIRES EXTERNES ENREGISTRES ---"
           STRING
               "sqlite3 -header -column data/banque.db "
               WS-DBL-QUOTE
               "SELECT id_beneficiaire, nom_beneficiaire, iban_beneficiaire, banque_destinataire FROM beneficiaires_externes;"
               WS-DBL-QUOTE
               DELIMITED BY SIZE INTO WS-COMMAND
           END-STRING
           CALL "SYSTEM" USING WS-COMMAND
           
           DISPLAY "ID du Bénéficiaire externe : " NO ADVANCING
           ACCEPT WS-ID-BENEF
           DISPLAY "Montant du transfert (ex: 500.00) : " NO ADVANCING
           ACCEPT WS-MONTANT-STR
           DISPLAY "Motif du virement : " NO ADVANCING
           ACCEPT WS-MOTIF
           
           PERFORM ESCAPE-MOTIF-QUOTES
           
           -- Débit et journalisation sécurisée avec capture automatique de l'IBAN distant
           STRING
               "sqlite3 data/banque.db "
               WS-DBL-QUOTE
               "BEGIN TRANSACTION; "
               "UPDATE comptes SET solde = solde - " FUNCTION TRIM(WS-MONTANT-STR)
               " WHERE id_compte = " WS-ID-EMETTEUR " AND solde >= " FUNCTION TRIM(WS-MONTANT-STR) "; "
               "INSERT INTO virements (id_compte_emetteur, type_virement, beneficiaire_externe_id, iban_destinataire, montant, motif, statut) "
               "SELECT " WS-ID-EMETTEUR ", 'EXTERNE', " WS-ID-BENEF ", iban_beneficiaire, " FUNCTION TRIM(WS-MONTANT-STR) ", "
               WS-SGL-QUOTE FUNCTION TRIM(WS-MOTIF) WS-SGL-QUOTE ", "
               "CASE WHEN changes() > 0 THEN 'EXECUTE' ELSE 'ECHEC' END FROM beneficiaires_externes WHERE id_beneficiaire = " WS-ID-BENEF "; "
               "COMMIT;"
               WS-DBL-QUOTE
               DELIMITED BY SIZE INTO WS-COMMAND
           END-STRING
           
           CALL "SYSTEM" USING WS-COMMAND
           DISPLAY "✔️ Ordre transmis avec succès à la passerelle interbancaire.".

       HISTORIQUE-MENU.
           DISPLAY " "
           DISPLAY "--- MODULE DE RECHERCHE & RAPPORTS ---"
           DISPLAY "1. Tous les virements émis (Global)"
           DISPLAY "2. Filtrer par Client spécifique"
           DISPLAY "3. Statistiques mensuelles de flux"
           DISPLAY "Choix du rapport (1-3) : " NO ADVANCING
           ACCEPT WS-SUB-CHOICE
           
           EVALUATE WS-SUB-CHOICE
               WHEN 1
                   STRING
                       "sqlite3 -header -column data/banque.db "
                       WS-DBL-QUOTE
                       "SELECT id_virement, type_virement, montant, date_virement, statut, reference FROM virements ORDER BY date_virement DESC;"
                       WS-DBL-QUOTE
                       DELIMITED BY SIZE INTO WS-COMMAND
                   END-STRING
                   CALL "SYSTEM" USING WS-COMMAND
               WHEN 2
                   DISPLAY "Entrez l'ID du client : " NO ADVANCING
                   ACCEPT WS-CLIENT-ID
                   STRING
                       "sqlite3 -header -column data/banque.db "
                       WS-DBL-QUOTE
                       "SELECT v.id_virement, v.type_virement, v.montant, v.date_virement, v.statut, v.motif "
                       "FROM virements v JOIN comptes c ON v.id_compte_emetteur = c.id_compte "
                       "WHERE c.id_client = " WS-CLIENT-ID " ORDER BY v.date_virement DESC;"
                       WS-DBL-QUOTE
                       DELIMITED BY SIZE INTO WS-COMMAND
                   END-STRING
                   CALL "SYSTEM" USING WS-COMMAND
               WHEN 3
                   STRING
                       "sqlite3 -header -column data/banque.db "
                       WS-DBL-QUOTE
                       "SELECT strftime('%Y-%m', date_virement) AS Mois, SUM(montant) AS Total_Emis_EUR "
                       "FROM virements WHERE statut = 'EXECUTE' GROUP BY Mois ORDER BY Mois DESC;"
                       WS-DBL-QUOTE
                       DELIMITED BY SIZE INTO WS-COMMAND
                   END-STRING
                   CALL "SYSTEM" USING WS-COMMAND
               WHEN OTHER
                   DISPLAY "Annulation. Retour au menu principal."
           END-EVALUATE.

       ESCAPE-MOTIF-QUOTES.
           INSPECT WS-MOTIF REPLACING ALL "'" BY " ".
