-- =============================================
-- BASE DE DONNÉES POUR GESTION DE VIREMENTS
-- =============================================

CREATE TABLE IF NOT EXISTS clients (
    id_client     INTEGER PRIMARY KEY AUTOINCREMENT,
    nom           VARCHAR(50) NOT NULL,
    prenom        VARCHAR(50) NOT NULL,
    date_naissance DATE,
    adresse       TEXT,
    telephone     VARCHAR(20),
    email         VARCHAR(100)
);

CREATE TABLE IF NOT EXISTS comptes (
    id_compte     INTEGER PRIMARY KEY AUTOINCREMENT,
    id_client     INTEGER NOT NULL,
    numero_compte VARCHAR(20) UNIQUE NOT NULL,
    iban          VARCHAR(34) UNIQUE NOT NULL,
    solde         DECIMAL(15,2) NOT NULL CHECK (solde >= 0),
    devise        CHAR(3) DEFAULT 'EUR',
    date_ouverture DATE DEFAULT CURRENT_DATE,
    actif         BOOLEAN DEFAULT 1,
    FOREIGN KEY (id_client) REFERENCES clients(id_client) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS beneficiaires_externes (
    id_beneficiaire INTEGER PRIMARY KEY AUTOINCREMENT,
    id_client_proprietaire INTEGER NOT NULL,
    nom_beneficiaire VARCHAR(100) NOT NULL,
    iban_beneficiaire VARCHAR(34) NOT NULL,
    bic_beneficiaire VARCHAR(11) NOT NULL,
    banque_destinataire VARCHAR(100),
    actif BOOLEAN DEFAULT 1,
    date_ajout DATE DEFAULT CURRENT_DATE,
    FOREIGN KEY (id_client_proprietaire) REFERENCES clients(id_client) ON DELETE CASCADE,
    UNIQUE(id_client_proprietaire, iban_beneficiaire)
);

CREATE TABLE IF NOT EXISTS virements (
    id_virement   INTEGER PRIMARY KEY AUTOINCREMENT,
    id_compte_emetteur INTEGER NOT NULL,
    type_virement VARCHAR(10) NOT NULL,
    id_compte_destinataire INTEGER,
    beneficiaire_externe_id INTEGER,
    iban_destinataire VARCHAR(34),
    montant       DECIMAL(15,2) NOT NULL CHECK (montant > 0),
    date_virement TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    motif         VARCHAR(140),
    statut        VARCHAR(20) DEFAULT 'EN_ATTENTE',
    reference     VARCHAR(50) UNIQUE,
    FOREIGN KEY (id_compte_emetteur) REFERENCES comptes(id_compte) ON DELETE CASCADE,
    FOREIGN KEY (id_compte_destinataire) REFERENCES comptes(id_compte) ON DELETE SET NULL,
    FOREIGN KEY (beneficiaire_externe_id) REFERENCES beneficiaires_externes(id_beneficiaire) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS historique_virements (
    id_historique INTEGER PRIMARY KEY AUTOINCREMENT,
    id_virement   INTEGER NOT NULL,
    action        VARCHAR(20) NOT NULL,
    date_action   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ancien_statut VARCHAR(20),
    nouveau_statut VARCHAR(20),
    commentaire   TEXT,
    FOREIGN KEY (id_virement) REFERENCES virements(id_virement) ON DELETE CASCADE
);

-- Index pour les performances
CREATE INDEX IF NOT EXISTS idx_comptes_iban ON comptes(iban);
CREATE INDEX IF NOT EXISTS idx_virements_emetteur ON virements(id_compte_emetteur);
CREATE INDEX IF NOT EXISTS idx_virements_date ON virements(date_virement);
CREATE INDEX IF NOT EXISTS idx_historique_virement ON historique_virements(id_virement);

-- Triggers pour automatiser les logs et références uniques
CREATE TRIGGER IF NOT EXISTS after_insert_virements_ref
AFTER INSERT ON virements
WHEN NEW.reference IS NULL
BEGIN
    UPDATE virements 
    SET reference = 'VIR' || strftime('%Y%m%d%H%M%S', 'now') || abs(random() % 10000)
    WHERE id_virement = NEW.id_virement;
    
    INSERT INTO historique_virements (id_virement, action, -statut, nouveau_statut, commentaire)
    VALUES (NEW.id_virement, 'CREATION', NULL, NEW.statut, 'Initialisation sécurisée');
END;

CREATE TRIGGER IF NOT EXISTS after_update_virements_statut
AFTER UPDATE OF statut ON virements
FOR EACH ROW
BEGIN
    INSERT INTO historique_virements (id_virement, action, ancien_statut, nouveau_statut, commentaire)
    VALUES (OLD.id_virement, 'CHANGEMENT_STATUT', OLD.statut, NEW.statut, 'Mise à jour par traitement transactionnel');
END;

-- Insertion de données de test (Clients, Comptes, Bénéficiaires)
INSERT OR IGNORE INTO clients (id_client, nom, prenom, date_naissance, adresse, telephone, email) VALUES
(1, 'Dupont', 'Jean', '1980-05-12', '12 rue de Paris, 75001 Paris', '0612345678', 'jean.dupont@email.fr'),
(2, 'Martin', 'Sophie', '1992-09-23', '45 avenue des Champs, 69000 Lyon', '0698765432', 'sophie.martin@email.fr'),
(3, 'Dubois', 'Pierre', '1975-11-02', '8 place de la Banque, 13000 Marseille', '0678123456', 'pierre.dubois@email.fr');

INSERT OR IGNORE INTO comptes (id_compte, id_client, numero_compte, iban, solde) VALUES
(1, 1, '00012345678', 'FR7612345000012345678901', 5250.75),
(2, 1, '00012345679', 'FR7612345000012345678902', 12000.00),
(3, 2, '00087654321', 'FR7698765000012345678903', 3850.30),
(4, 3, '00011223344', 'FR7630001000012345678904', 9200.00);

INSERT OR IGNORE INTO beneficiaires_externes (id_beneficiaire, id_client_proprietaire, nom_beneficiaire, iban_beneficiaire, bic_beneficiaire, banque_destinataire) VALUES
(1, 1, 'Société Générale', 'FR7630001000012345678905', 'SOGEFRPP', 'Société Générale'),
(2, 2, 'BNP Paribas', 'FR7612345000012345678906', 'BNPAFRPP', 'BNP Paribas'),
(3, 1, 'Loyer', 'DE89370400440532013000', 'COBADEFF', 'Commerzbank');
